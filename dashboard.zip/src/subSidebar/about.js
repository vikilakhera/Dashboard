
  
export const AboutUs = () => {
  return (
    <div className="home">
      <h1> About us</h1>
    </div>
  );
};
  
export const OurAim = () => {
  return (
    <div className="home">
      <h1> Aim</h1>
    </div>
  );
};
  
export const OurVision = () => {
  return (
    <div className="home">
      <h1>Vision</h1>
    </div>
  );
};

export const Contact = () => {
    return(
        <div className="contact">
            <h3>Contact us at 1140-776738 </h3>
        </div>
    );
};

export const Events = () => {
    return (
      <div className="events">
        <h1>Events</h1>
      </div>
    );
  };
    
export const EventsOne = () => {
    return (
      <div className="events">
        <h1>Event1</h1>
      </div>
    );
  };
    
export const EventsTwo = () => {
    return (
      <div className="events">
        <h1>Event2</h1>
      </div>
    );
  };

export const Services = () => {
    return (
      <div className="services">
        <h1>Services</h1>
      </div>
    );
  };
    
export const ServicesOne = () => {
    return (
      <div className="services">
        <h1>Service1</h1>
      </div>
    );
  };
    
export const ServicesTwo = () => {
    return (
      <div className="services">
        <h1>Service2</h1>
      </div>
    );
  };
    
export const ServicesThree = () => {
    return (
      <div className="services">
        <h1>Service3</h1>
      </div>
    );
  };

export const Support = () => {
    return (
      <div className="support">
        <h1>Support us</h1>
      </div>
    );
  };